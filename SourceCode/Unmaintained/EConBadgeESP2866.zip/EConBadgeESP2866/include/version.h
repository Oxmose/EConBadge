
#ifndef BUILD_NUMBER
  #define BUILD_NUMBER "215"
#endif
#ifndef VERSION
  #define VERSION "v0.1.215\n2022-12-21 22:39:51"
#endif
#ifndef VERSION_SHORT
  #define VERSION_SHORT "v0.1.215"
#endif
